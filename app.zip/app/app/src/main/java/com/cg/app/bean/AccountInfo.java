package com.cg.app.bean;


import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

//Collection to store Account Details of user
@Document
public class AccountInfo {
	
	@Id
	private String id;
	private String password;
	private String accountNo;
	private String accountType;
	private String ifscCode;
	private String branch;
	private String mobileNo;
	private String email;
	private String debitCardNumber;
	
	private List<Transactions> transactions;
	
	
	//Default Constructor
	public AccountInfo() {
		// TODO Auto-generated constructor stub
	}
	
	
	//Parameterized Constructor
	public AccountInfo(String id, String password, String accountNo, String accountType, String ifscCode, String branch,
			String mobileNo, String email, String debitCardNumber, List<Transactions> transactions) {
		super();
		this.id = id;
		this.password = password;
		this.accountNo = accountNo;
		this.accountType = accountType;
		this.ifscCode = ifscCode;
		this.branch = branch;
		this.mobileNo = mobileNo;
		this.email = email;
		this.debitCardNumber = debitCardNumber;
		this.transactions = transactions;
	}

	//Getters & Setters
	
	public String getDebitCardNumber() {
		return debitCardNumber;
	}

	public void setDebitCardNumber(String debitCardNumber) {
		this.debitCardNumber = debitCardNumber;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getAccountNo() {
		return accountNo;
	}


	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}


	public String getAccountType() {
		return accountType;
	}


	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}


	public String getIfscCode() {
		return ifscCode;
	}


	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}


	public String getBranch() {
		return branch;
	}


	public void setBranch(String branch) {
		this.branch = branch;
	}


	public String getMobileNo() {
		return mobileNo;
	}


	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public List<Transactions> getTransactions() {
		return transactions;
	}


	public void setTransactions(List<Transactions> transactions) {
		this.transactions = transactions;
	}




	@Override
	public String toString() {
		return "AccountInfo [id=" + id + ", password=" + password + ", accountNo=" + accountNo + ", accountType="
				+ accountType + ", ifscCode=" + ifscCode + ", branch=" + branch + ", mobileNo=" + mobileNo + ", email="
				+ email + ", debitCardNumber=" + debitCardNumber + ", transactions=" + transactions + "]";
	}
	
	
		
	
}
