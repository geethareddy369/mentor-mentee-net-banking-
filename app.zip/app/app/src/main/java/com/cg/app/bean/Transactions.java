package com.cg.app.bean;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;


//Collection to store Transactions Of user 
@Document
public class Transactions {
	
	private long deposit;
	private long withdraw;
	private long balance;
	private Date date;
	
	//Default Constructor
	public Transactions() {
		// TODO Auto-generated constructor stub
	}
	

	//Parameterized constructor
	public Transactions(long deposit, long withdraw, long balance, Date date) {
		super();
		this.deposit = deposit;
		this.withdraw = withdraw;
		this.balance = balance;
		this.date = date;
	}


	//Getters & Setters
	public Date getDate() {
		return date;
	}
	
	public void setDate(Date date2) {
		this.date = date2;
	}

	public long getDeposit() {
		return deposit;
	}

	public void setDeposit(long deposit) {
		this.deposit = deposit;
	}

	public long getWithdraw() {
		return withdraw;
	}

	public void setWithdraw(long withdraw) {
		this.withdraw = withdraw;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Transactions [deposit=" + deposit + ", withdraw=" + withdraw + ", balance=" + balance + "]";
	}

	
	

}
