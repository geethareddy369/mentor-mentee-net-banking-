package com.cg.app.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.app.service.BankingServiceI;

//Rest Controller to perform ATM Operations
@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/atm")
public class AtmController {

	
	@Autowired
	BankingServiceI service;
	
	
	//DEPOSIT
	@PostMapping("/deposit")
	public String deposit(@RequestParam("debitCardNumber") String debitCardNumber,@RequestParam("deposit") long deposit)
	{
		 
		return service.deposit(debitCardNumber,deposit);
	}
	
	
	//WITHDRAW
	@PostMapping("/withdraw")
	public String withdraw(@RequestParam("debitCardNumber") String debitCardNumber,@RequestParam("withdraw") long withdraw)
	{
		 
		return service.withdraw(debitCardNumber,withdraw);
	}
	
	
	//BALANCE CHECK
	@GetMapping("balance")
	public long balanceCheck(@RequestParam("id") String id) {
		return service.balanceCheck(id);
	}
	
}
