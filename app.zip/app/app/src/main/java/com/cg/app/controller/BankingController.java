package com.cg.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.app.bean.AccountInfo;
import com.cg.app.bean.Transactions;
import com.cg.app.service.BankingServiceI;

//Rest Controller to perform Net Banking Operations
@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/banking")
public class BankingController {
	
	
	@Autowired
	BankingServiceI service;
	
	
	//to fetch transaction history
	@GetMapping("/transactions")
    public List<Transactions> transactionDetails(@RequestParam("username") String id){
	   return service.transactions(id);
	}
	
	
	
	//to get account details of user based on username
	@GetMapping("/getAccountSummary")
	public AccountInfo getDetails(@RequestParam("username") String id) {
		return service.getAccountDetails(id);
	}
		
	
	
	//login validation
	@GetMapping("/validateuser")
	public boolean validateLogin(@RequestParam("username") String id,@RequestParam("password") String password) {
		return service.validateUser(id, password);
	}
		

}
