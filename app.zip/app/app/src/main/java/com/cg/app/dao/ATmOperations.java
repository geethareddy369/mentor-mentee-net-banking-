package com.cg.app.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.app.bean.AccountInfo;
import com.cg.app.bean.Transactions;

@Repository
public class ATmOperations {

	@Autowired
	MongoTemplate mongoTemplate;
	
	String id = null;
	String password = null;
	String accountNo = null;
	String accountType = null;
	String ifscCode = null;
	String branch = null;
	String mobileNo = null;
	String email = null;
	List<Transactions> transactions = null;
	long balance = 0;
	
	AccountInfo a=new AccountInfo();
	Transactions t=new Transactions();
	
	
	//Depositing money into account 
	public String deposit(long deposit, String debitCardNumber) {
		int count=0;
		List<AccountInfo> details=mongoTemplate.findAll(AccountInfo.class);
		for(AccountInfo d:details)
		{
				if(d.getDebitCardNumber().equals(debitCardNumber))
				{
					count=1;
					id=d.getId();
					accountNo=d.getAccountNo();
					accountType=d.getAccountType();
					branch=d.getBranch();
					email=d.getEmail();
					ifscCode=d.getIfscCode();
					mobileNo=d.getMobileNo();
					password=d.getPassword();
					transactions=d.getTransactions();
				
					//fetching the last transaction
						Transactions lastTransaction = transactions.get(transactions.size() - 1); 
			     
			        // balance of last transaction
						balance=lastTransaction.getBalance();
			       
			        //updating the balance
			            balance=balance+deposit;
			     }
				
			}
		if(count==0)
			return "invalid debit card number";
		
		t.setDeposit(deposit);
		t.setWithdraw(0);
		t.setBalance(balance);
		t.setDate(new Date());
		transactions.add(t);
		
		
		a.setId(id);
		a.setAccountNo(accountNo);
		a.setAccountType(accountType);
		a.setBranch(branch);
		a.setDebitCardNumber(debitCardNumber);
		a.setEmail(email);
		a.setIfscCode(ifscCode);
		a.setMobileNo(mobileNo);
		a.setPassword(password);
		a.setTransactions(transactions);
	
		mongoTemplate.save(a);
		return "Amount deposited successfully";
		
	}
	
	
	
	//Withdraw money from Account
	public String withdraw(long withdraw, String debitCardNumber) {
		int count=0;
		List<AccountInfo> details=mongoTemplate.findAll(AccountInfo.class);
		
		for(AccountInfo d:details)
		{
			
				if(d.getDebitCardNumber().equals(debitCardNumber)) {
					count=1;
					id=d.getId();
					accountNo=d.getAccountNo();
					accountType=d.getAccountType();
					branch=d.getBranch();
					email=d.getEmail();
					ifscCode=d.getIfscCode();
					mobileNo=d.getMobileNo();
					password=d.getPassword();
					transactions=d.getTransactions();
				
				   //fetching the last transaction
			          Transactions lastTransaction = transactions.get(transactions.size() - 1); 
			       //balance of last transaction
			          balance=lastTransaction.getBalance();
			          if(balance>withdraw) {
			       //update the balance
			          balance=balance-withdraw;
			          }
			          else {
			        	  return "unable to withdraw less balance";
			        	 
			          }
			     }
				if(count==1)
					break;
					
			}
		if(count==0)
			return "invalid debit card";
		
		
		
		t.setDeposit(0);
		t.setWithdraw(withdraw);
		t.setBalance(balance);
		t.setDate(new Date());
		
		transactions.add(t);
		
		a.setId(id);
		a.setAccountNo(accountNo);
		a.setAccountType(accountType);
		a.setBranch(branch);
		a.setDebitCardNumber(debitCardNumber);
		a.setEmail(email);
		a.setIfscCode(ifscCode);
		a.setMobileNo(mobileNo);
		a.setPassword(password);
		a.setTransactions(transactions);
		
		mongoTemplate.save(a);
		return "Amount withdrawn succcesfully";
		
	}


	//Balance Check
	public long balanceCheck(String id) {
		List<Transactions> transactions=new ArrayList<Transactions>();
		AccountInfo a=mongoTemplate.findById(id, AccountInfo.class);
		transactions=a.getTransactions();
		Transactions lastTransaction = transactions.get(transactions.size() - 1); 
		long balance=lastTransaction.getBalance();
		return balance;
	}
	
	

	
	
}
