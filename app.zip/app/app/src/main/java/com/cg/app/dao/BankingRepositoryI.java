package com.cg.app.dao;

import java.util.List;

import com.cg.app.bean.AccountInfo;
import com.cg.app.bean.Transactions;

public interface BankingRepositoryI {

	
	AccountInfo getAccountDetails(String username);

	boolean validateUser(String username, String password);

	List<Transactions> transactions(String id);

}
