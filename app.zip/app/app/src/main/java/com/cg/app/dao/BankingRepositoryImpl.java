package com.cg.app.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;

import org.springframework.stereotype.Repository;

import com.cg.app.bean.AccountInfo;
import com.cg.app.bean.Transactions;

//Banking Repository to fetch Account Details and Transaction History
@Repository
public class BankingRepositoryImpl implements BankingRepositoryI{

	
	@Autowired
	MongoTemplate mongoTemplate;
	
	
	
	//fetching Account details of user based on username
	@Override
	public AccountInfo getAccountDetails(String username) {
		return mongoTemplate.findById(username, AccountInfo.class);
		
		
	}

	
	
	//validating the user based on username and password
	@Override
	public boolean validateUser(String username, String password) {
		List<AccountInfo> details=mongoTemplate.findAll(AccountInfo.class);
		for(AccountInfo d:details) {
			if(d.getId().equals(username)&&(d.getPassword().equals(password))) {
				return true;
			}
		}
		return false;
	}

	

	//To fetch transaction history based on username
	@Override
	public List<Transactions> transactions(String id) {
		AccountInfo a=mongoTemplate.findById(id, AccountInfo.class);
	 String debitCardNumber=a.getDebitCardNumber();
	 List<AccountInfo> details=mongoTemplate.findAll(AccountInfo.class);
	 for (AccountInfo accountInfo : details) {
		if(accountInfo.getDebitCardNumber().equals(debitCardNumber)) {
			return accountInfo.getTransactions();
		}
	}
		return null;
		
	}

	

}
