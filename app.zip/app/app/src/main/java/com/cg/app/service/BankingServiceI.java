package com.cg.app.service;

import java.util.List;

import com.cg.app.bean.AccountInfo;
import com.cg.app.bean.Transactions;

public interface BankingServiceI {

	AccountInfo getAccountDetails(String username);

	boolean validateUser(String username, String password);

	List<Transactions> transactions(String id);

	String deposit(String debitCardNumber, long deposit);

	String withdraw(String debitCardNumber, long withdraw);

	long balanceCheck(String id);

}
