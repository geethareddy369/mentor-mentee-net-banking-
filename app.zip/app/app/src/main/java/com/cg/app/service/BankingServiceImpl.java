package com.cg.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.app.bean.AccountInfo;
import com.cg.app.bean.Transactions;
import com.cg.app.dao.ATmOperations;
import com.cg.app.dao.BankingRepositoryI;

@Service
public class BankingServiceImpl implements BankingServiceI{

	
	@Autowired
	BankingRepositoryI dao;
	
	@Autowired
	ATmOperations atm;
	
	
	
	//Banking operations
	
	
	//Verify User Login
	@Override
	public boolean validateUser(String username, String password) {
		return dao.validateUser(username, password);
	}
	
	
	
	//Account Details
	@Override
	public AccountInfo getAccountDetails(String username) {
	return dao.getAccountDetails(username);
	}


	
	//to diaplay Transaction History
	@Override
	public List<Transactions> transactions(String id) {
		return dao.transactions(id);
		
	}
	
	
	
	
	//To perform ATM operations

	
	//deposit
	@Override
	public String deposit(String debitCardNumber, long deposit) {
		return atm.deposit(deposit, debitCardNumber);
		
	}

	
	//withdraw
	@Override
	public String withdraw(String debitCardNumber, long withdraw) {
		return atm.withdraw(withdraw, debitCardNumber);
		
	}

	
	//check balance
	@Override
	public long balanceCheck(String id) {
		return atm.balanceCheck(id);
	}

}
